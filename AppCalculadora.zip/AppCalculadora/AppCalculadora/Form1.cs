﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txt1.Text);
            int num2 = int.Parse(txt2.Text);
            float resultado;

            //Divisão;
            resultado = num1 / num2;
            MessageBox.Show("Divisão: " + resultado);
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txt1.Text);
            int num2 = int.Parse(txt2.Text);
            float resultado;

            //Subtração;
            resultado = num1 - num2;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txt1.Text);
            int num2 = int.Parse(txt2.Text);
            float resultado;

            //Multiplicação;
            resultado = num1 * num2;
            MessageBox.Show("Multiplicação: " + resultado);
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txt1.Text);
            int num2 = int.Parse(txt2.Text);
            float resultado;

            //Soma;
            resultado = num1 + num2;
            MessageBox.Show("Adição: " + resultado);
        }
    }
}
