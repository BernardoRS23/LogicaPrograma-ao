﻿namespace AppLista03
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.btnMedia = new System.Windows.Forms.Button();
            this.lblNum01 = new System.Windows.Forms.Label();
            this.txtNum01 = new System.Windows.Forms.TextBox();
            this.txtNum02 = new System.Windows.Forms.TextBox();
            this.txtNum03 = new System.Windows.Forms.TextBox();
            this.lblNum02 = new System.Windows.Forms.Label();
            this.lblNum03 = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMedia
            // 
            this.btnMedia.Location = new System.Drawing.Point(283, 157);
            this.btnMedia.Name = "btnMedia";
            this.btnMedia.Size = new System.Drawing.Size(85, 23);
            this.btnMedia.TabIndex = 3;
            this.btnMedia.Text = "Média";
            this.btnMedia.UseVisualStyleBackColor = true;
            this.btnMedia.Click += new System.EventHandler(this.btnMedia_Click);
            // 
            // lblNum01
            // 
            this.lblNum01.AutoSize = true;
            this.lblNum01.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum01.ForeColor = System.Drawing.Color.White;
            this.lblNum01.Location = new System.Drawing.Point(68, 78);
            this.lblNum01.Name = "lblNum01";
            this.lblNum01.Size = new System.Drawing.Size(119, 25);
            this.lblNum01.TabIndex = 4;
            this.lblNum01.Text = "1º Número:";
            // 
            // txtNum01
            // 
            this.txtNum01.Location = new System.Drawing.Point(73, 106);
            this.txtNum01.Name = "txtNum01";
            this.txtNum01.Size = new System.Drawing.Size(100, 20);
            this.txtNum01.TabIndex = 7;
            // 
            // txtNum02
            // 
            this.txtNum02.Location = new System.Drawing.Point(73, 170);
            this.txtNum02.Name = "txtNum02";
            this.txtNum02.Size = new System.Drawing.Size(100, 20);
            this.txtNum02.TabIndex = 8;
            // 
            // txtNum03
            // 
            this.txtNum03.Location = new System.Drawing.Point(73, 239);
            this.txtNum03.Name = "txtNum03";
            this.txtNum03.Size = new System.Drawing.Size(100, 20);
            this.txtNum03.TabIndex = 9;
            // 
            // lblNum02
            // 
            this.lblNum02.AutoSize = true;
            this.lblNum02.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum02.ForeColor = System.Drawing.Color.White;
            this.lblNum02.Location = new System.Drawing.Point(68, 142);
            this.lblNum02.Name = "lblNum02";
            this.lblNum02.Size = new System.Drawing.Size(119, 25);
            this.lblNum02.TabIndex = 10;
            this.lblNum02.Text = "2º Número:";
            // 
            // lblNum03
            // 
            this.lblNum03.AutoSize = true;
            this.lblNum03.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNum03.ForeColor = System.Drawing.Color.White;
            this.lblNum03.Location = new System.Drawing.Point(68, 211);
            this.lblNum03.Name = "lblNum03";
            this.lblNum03.Size = new System.Drawing.Size(119, 25);
            this.lblNum03.TabIndex = 11;
            this.lblNum03.Text = "3º Número:";
            // 
            // btnSomar
            // 
            this.btnSomar.Location = new System.Drawing.Point(283, 186);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(85, 23);
            this.btnSomar.TabIndex = 12;
            this.btnSomar.Text = "Soma";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkRed;
            this.ClientSize = new System.Drawing.Size(444, 359);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.lblNum03);
            this.Controls.Add(this.lblNum02);
            this.Controls.Add(this.txtNum03);
            this.Controls.Add(this.txtNum02);
            this.Controls.Add(this.txtNum01);
            this.Controls.Add(this.lblNum01);
            this.Controls.Add(this.btnMedia);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao01";
            this.Text = "Calculadora";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnMedia;
        private System.Windows.Forms.Label lblNum01;
        private System.Windows.Forms.TextBox txtNum01;
        private System.Windows.Forms.TextBox txtNum02;
        private System.Windows.Forms.TextBox txtNum03;
        private System.Windows.Forms.Label lblNum02;
        private System.Windows.Forms.Label lblNum03;
        private System.Windows.Forms.Button btnSomar;
    }
}

